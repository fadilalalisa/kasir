<tr>
                        
                    </tr>

                    <td><?=$row['harga_pokok_sat'];?></td>
                        <td><?=$row['harga_pokok_lsn'];?></td>
                        <td><?=$row['harga_pokok_krt'];?></td>
                        <td><?= $row['harga_jual_sat']; ?></td>
                        <td><?= $row['harga_jual_lsn']; ?></td>
                        <td><?= $row['harga_jual_krt']; ?></td>